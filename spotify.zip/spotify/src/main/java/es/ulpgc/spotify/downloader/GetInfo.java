package es.ulpgc.spotify.downloader;

import com.google.gson.*;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class GetInfo {

    private final HashMap<String, String> artists;
    SpotifyAccessor accessor;

    {
        try {
            accessor = new SpotifyAccessor();
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }
    List<String> albumlist = new ArrayList<>();
    List<Artist> artistas = new ArrayList<>();
    List<Albums> albums = new ArrayList<>();
    List<Tracks> tracks = new ArrayList<>();

    public GetInfo(HashMap<String, String> artists) {
        this.artists = artists;
        this.accessor = accessor;
        this.albumlist = albumlist;
        this.artistas = artistas;
        this.albums = albums;
        this.tracks = tracks;
    }

    public void getTracks(List<String> albumlist, List<Tracks> tracks) {
        for (String albumid : albumlist) {
            try {
                String response = accessor.get("/albums/" + albumid + "/tracks", Map.of());
                JsonElement element = JsonParser.parseString(response);
                JsonObject object = element.getAsJsonObject();
                JsonArray items = object.get("items").getAsJsonArray();
                for (JsonElement item : items) {
                    JsonObject itemJson = item.getAsJsonObject();
                    String name = (itemJson.get("name").getAsString());
                    String id = (itemJson.get("id").getAsString());
                    boolean explicit = (itemJson.get("explicit").getAsBoolean());
                    int duration_ms = (itemJson.get("duration_ms").getAsInt());
                    JsonArray arrayJson = itemJson.get("artists").getAsJsonArray();
                    for (JsonElement array : arrayJson) {
                        JsonObject artistJson = array.getAsJsonObject();
                        String artist_name = (artistJson.get("name").getAsString());
                        String artist_id = (artistJson.get("id").getAsString());
                        Tracks tracks1 = new Tracks(name, id, explicit, duration_ms, artist_name, artist_id);
                        tracks.add(tracks1);
                    }
                }
            } catch (Exception e) {
                throw new RuntimeException(e);
            }
        }
    }

    public void getAlbums(HashMap<String, String> artists, List<Albums> albums, List<String> albumlist) {
        for (String artist : artists.keySet()) {
            try {
                String response = accessor.get("/artists/" + artist + "/albums", Map.of());
                JsonElement element = JsonParser.parseString(response);
                JsonObject object = element.getAsJsonObject();
                JsonArray items = object.get("items").getAsJsonArray();
                for (JsonElement item : items) {
                    JsonObject objectitem = item.getAsJsonObject();
                    String name =(objectitem.get("name").getAsString());
                    String id = (objectitem.get("id").getAsString());
                    albumlist.add(objectitem.get("id").getAsString());
                    String release_date = (objectitem.get("release_date").getAsString());
                    int total_tracks = (objectitem.get("total_tracks").getAsInt());
                    JsonArray arrayJson = objectitem.get("artists").getAsJsonArray();
                    for (JsonElement array : arrayJson) {
                        JsonObject artistJson = array.getAsJsonObject();
                        String artist_name = (artistJson.get("name").getAsString());
                        String artist_id = (artistJson.get("id").getAsString());
                        Albums albums1 = new Albums(name, id, release_date, total_tracks, artist_name, artist_id);
                        albums.add(albums1);
                    }
                }
            } catch (Exception e) {
                throw new RuntimeException(e);
            }

        }
    }

    public void getArtist(HashMap<String, String> artists, List<Artist> artistas) throws Exception {
        for (String id : artists.keySet()) {
            String response = accessor.get("/artists/" + id, Map.of());
            Gson gson = new Gson();
            JsonElement element = JsonParser.parseString(response);
            JsonObject object = element.getAsJsonObject();
            String name = (object.get("name").getAsString());
            String ident = (object.get("id").getAsString());
            int popularity = (object.get("popularity").getAsInt());
            Artist artist = new Artist(name, ident, popularity);
            artistas.add(artist);
        }
    }
}
