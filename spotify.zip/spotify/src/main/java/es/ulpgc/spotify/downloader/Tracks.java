package es.ulpgc.spotify.downloader;

import java.util.Arrays;

public class Tracks {
    private String name;
    private String id;
    private boolean explicit;
    private int duration_ms;
    private String artist_name;
    private String artist_id;

    public Tracks(String name, String id, boolean explicit, int duration_ms, String artist_name, String artist_id) {
        this.name = name;
        this.id = id;
        this.explicit = explicit;
        this.duration_ms = duration_ms;
        this.artist_name = artist_name;
        this.artist_id = artist_id;
    }

    public String getName() {
        return name;
    }

    public String getId() {
        return id;
    }

    public boolean isExplicit() {
        return explicit;
    }

    public int getDuration_ms() {
        return duration_ms;
    }

    public String getArtist_name() {
        return artist_name;
    }

    public String getArtist_id() {
        return artist_id;
    }
}
