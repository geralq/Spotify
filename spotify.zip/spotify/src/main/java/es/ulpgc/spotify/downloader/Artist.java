package es.ulpgc.spotify.downloader;

import java.util.ArrayList;
import java.util.List;

public class Artist {

    private String name;
    private String id;
    private int popularity;

    public Artist(String name, String id, int popularity) {
        this.name = name;
        this.id = id;
        this.popularity = popularity;
    }

    public String getName() {
        return name;
    }

    public String getId() {
        return id;
    }

    public int getPopularity() {
        return popularity;
    }

}
