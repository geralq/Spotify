package es.ulpgc.spotify.downloader;

import java.util.Arrays;
public class Albums {



    private String name;
    private String id;
    private String release_date;
    private int total_tracks;
    private String artist_name;
    private String artist_id;

    public Albums(String name, String id, String release_date, int total_tracks, String artist_name, String artist_id) {
        this.name = name;
        this.id = id;
        this.release_date = release_date;
        this.total_tracks = total_tracks;
        this.artist_name = artist_name;
        this.artist_id = artist_id;
    }

    public String getName() {
        return name;
    }

    public String getId() {
        return id;
    }

    public String getRelease_date() {
        return release_date;
    }

    public int getTotal_tracks() {
        return total_tracks;
    }

    public String getArtist_name() {
        return artist_name;
    }

    public String getArtist_id() {
        return artist_id;
    }
}
