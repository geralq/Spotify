package es.ulpgc.spotify.downloader;

import java.sql.*;

public class DatabaseController {
    String url = "jdbc:sqlite:C:\\Users\\Gerardo\\Desktop\\spotify\\database.db";
    Connection connection;

    {
        try {
            connection = DriverManager.getConnection(url);
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    Statement statement;

    {
        try {
            statement = connection.createStatement();
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    public DatabaseController() throws SQLException {
        this.url = url;
        this.connection = connection;
        this.statement = statement;
        connect();
        create_artist();
        create_albums();
        create_tracks();
    }

    private void create_artist() throws SQLException {
        String artista = "CREATE TABLE IF NOT EXISTS Artist (\n"
                + "name text,"
                + "id text PRIMARY KEY,"
                + "popularity integer"
                + ");";
        statement.execute(artista);
    }

    private void create_tracks() throws SQLException {
        String track = "CREATE TABLE IF NOT EXISTS Tracks (\n"
                + "name text,"
                + "id text PRIMARY KEY,"
                + "Explicit boolean,"
                + "duration_ms integer,"
                + "artist_name text,"
                + "artist_id text"
                + ");";
        statement.execute(track);
    }

    private void create_albums() throws SQLException {
        String album = "CREATE TABLE IF NOT EXISTS Albums (\n"
                + "name text,"
                + "id text PRIMARY KEY,"
                + "release_Date text,"
                + "total_tracks integer,"
                + "artist_name text,"
                + "artist_id text"
                + ");";
        statement.execute(album);
    }

    public void insert_artist(String name, String id, int popularity) throws SQLException {
        String sql = "INSERT INTO Artist(name, id, popularity) VALUES('%1$s','%2$s',%3$d) " +
                "ON CONFLICT(ID) DO UPDATE SET Name='%1$s', popularity=%3$d WHERE id='%2$s'";
        statement.execute(String.format(sql, name, id, popularity));
    }

    public void insert_albums(String name, String id, String release_date, int total_tracks, String artist_name, String artist_id) throws SQLException {
        String sql = "INSERT INTO Albums(name, id, release_date, total_tracks, artist_name, artist_id)" +
                "VALUES('%1$s','%2$s','%3$s',%4$d,'%5$s','%6$s') ON CONFLICT(id) " +
                "DO UPDATE SET name='%1$s', release_date = '%3$s', total_tracks = %4$d," +
                "artist_name = '%5$s', artist_id = '%6$s' WHERE id='%2$s'";
        name = name.replaceAll("'", " ");
        name = name.replaceAll("\"", " ");
        statement.execute(String.format(sql, name, id, release_date, total_tracks, artist_name, artist_id));
    }

    public void insert_tracks(String name, String id, boolean explicit, int duration_ms, String artist_name, String artist_id) throws SQLException {
        String sql = "INSERT INTO Tracks(name, id, explicit, duration_ms, artist_name, artist_id)" +
                "VALUES('%1$s','%2$s', %3$b, %4$d,'%5$s', '%6$s') ON CONFLICT(id) " +
                "DO UPDATE SET name='%1$s', explicit = %3$b, duration_ms = %4$d," +
                "artist_name = '%5$s', artist_id = '%6$s' WHERE id='%2$s'";
        name = name.replaceAll("'", " ");
        name = name.replaceAll("\"", " ");
        statement.execute(String.format(sql, name, id, explicit, duration_ms, artist_name, artist_id));
    }
    private void connect() {
        Connection conn = null;
        try {
            conn = DriverManager.getConnection(url);
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
    }
}


