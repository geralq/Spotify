package es.ulpgc.spotify.downloader;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Scanner;

public class Controller {

    HashMap<String, String> artists = new HashMap<String, String>() {{

        System.out.println("Welcome!");
        Scanner read = new Scanner(System.in);
        System.out.println("Write 1 if you want to add one artist's ID to the list.");
        System.out.println("Write 2 if you want to create a database with the list of artist.");

        while (true){

            int sing = read.nextInt();

            if (sing == 1) {
                System.out.println("You wrote 1.");
                System.out.println("Now write an artist's ID.");
                String id_artist = read.next();
                put(id_artist, " ");
                System.out.println("If you want to introduce another artist's ID to the list write 1 again," +
                        "if you want to create the database write 2.");
            } else if (sing == 2) {
                System.out.println("You wrote 2.");
                System.out.println("The database in being creating, please wait.");
                break;

            }else {
                System.out.println("You didn't write 1 or 2.");
                System.out.println("The program will finish.");
                System.exit(0);
            }
        }
    }};

    List<String> albumlist = new ArrayList<>();
    List<Artist> artistas = new ArrayList<>();
    List<Albums> albums = new ArrayList<>();
    List<Tracks> tracks = new ArrayList<>();

    private final GetInfo informacion = new GetInfo(artists);

    private final DatabaseController database = new DatabaseController();

    private final SpotifyAccessor acceso = new SpotifyAccessor();

    public Controller() throws Exception {
    }

    public void organizer() throws Exception {

        informacion.getArtist(artists, artistas);
        informacion.getAlbums(artists, albums, albumlist);
        informacion.getTracks(albumlist, tracks);

        for (Artist artista : artistas) {
            database.insert_artist(artista.getName(), artista.getId(),
                    artista.getPopularity());
        }

        for (Albums album : albums) {
            database.insert_albums(album.getName(), album.getId(),
                    album.getRelease_date(), album.getTotal_tracks(),
                    album.getArtist_name(), album.getArtist_id());
        }

        for (Tracks track : tracks) {
            database.insert_tracks(track.getName(), track.getId(),
                    track.isExplicit(), track.getDuration_ms(),
                    track.getArtist_name(), track.getArtist_id());
        }
    }
}